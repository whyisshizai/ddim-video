import math
import torch
import torch.nn as nn
class AttentionBlock(nn.Module):
    __doc__ = r"""self_attn in residual。

    IN:
        x: (B, in_channels, T, H, W)
        norm : group_norm
        num_groups (int): 默认: 32
    OUT:
        (B, in_channels, T,  H, W+)
    """

    def __init__(self, in_channels,num_groups=32,device=None):
        super().__init__()


        self.device = device
        self.in_channels = in_channels
        # 获取归一化层

        self.norm = nn.GroupNorm(num_groups,in_channels)

        # 空间注意力的QKV和输出投影层
        self.to_qkv_spatial = nn.Conv3d(in_channels, in_channels * 3, 1)  #空间Q,K,V
        self.to_out_spatial = nn.Conv3d(in_channels, in_channels, 1)  #处理输出

        # 时间注意力的QKV和输出投影层
        self.to_qkv_temporal = nn.Conv1d(in_channels, in_channels * 3, 1)  # 时间维度的QKV
        self.to_out_temporal = nn.Conv1d(in_channels, in_channels, 1)  #输出处理


    def forward(self, x, prompt_emb=None):
        b, c, t, h, w = x.shape

        #1空间注意力
        x_spatial = self.norm(x)

        qkv = self.to_qkv_spatial(x_spatial)  # 一次性生成QKV

        qkv = qkv.reshape(b, 3, self.in_channels, t, h, w)
        q, k, v = qkv[:, 0], qkv[:, 1], qkv[:, 2]

        # 优化维度变换,减少permute次数
        q = q.reshape(b, c, t, -1).transpose(-2, -1)  # [b, c, h*w, t]
        k = k.reshape(b, c, t, -1).transpose(-2, -1)
        v = v.reshape(b, c, t, -1).transpose(-2, -1)

        # 使用矩阵乘法代替einsum提高性能
        scale = 1.0 / math.sqrt(t)
        attention = torch.softmax((q @ k.transpose(-2, -1)) * scale, dim=-1)
        out = (attention @ v).transpose(-2, -1)
        out = out.reshape(b, c, t, h, w)

        # 空间注意力的残差连接
        out_spatial = self.to_out_spatial(out) + x
        #空间attn形状没变哦

        #2时间注意力

        #t展开失败了因为不能做到固定的t
        #除非expend t 2 c size
        #[bs,c,t,h,w]->
        #[bs,t,c,h,w]->
        #[bs,t, c*h*w]
        #x_temporal = (out_spatial.permute(0, 2, 1, 3, 4).reshape(b, t,-1))

        #试试  [b,c,t*w*h]
        x_temporal = (out_spatial.reshape(b, c,-1))

        if prompt_emb is not None:
            # 将时序特征作为query,提示特征作为key和value进行cross attention
            projection = nn.Linear(prompt_emb.shape[-1], t * h * w).to(self.device)
            prompt_proj = projection(prompt_emb)  # [b, t*h*w]

            # 计算cross attention
            scale = 1.0 / math.sqrt(prompt_proj.shape[-1])
            attention = torch.softmax((x_temporal @ prompt_proj.transpose(-2, -1)) * scale, dim=-1)
            x_temporal = attention @ prompt_proj
        #[1,c,t*h*w]
        # 优化时间维度的QKV生成
        x_t =  x_temporal  # [b, c*h*w, t]


        qkv_t = self.to_qkv_temporal(x_t)
        qkv_t = qkv_t.reshape(b, 3, self.in_channels, -1)
        q_t, k_t, v_t = qkv_t[:, 0], qkv_t[:, 1], qkv_t[:, 2]
        #q_t [b,c,h*h*t]
        # 使用矩阵乘法优化时间注意力计算
        scale_t = 1.0 / math.sqrt(c)

        attention_t = torch.softmax((q_t @ k_t.transpose(-2, -1)) * scale_t, dim=-1)
        #[1,128,128]
        out_t = attention_t @ v_t

        #[B,C,T*H*W]
        # 优化输出处理
        out_temporal = self.to_out_temporal(out_t)
        #[1,128,T*H*W]

        out_temporal = out_temporal.reshape(b, c, t, h, w)


        return out_temporal + out_spatial



#视频tensor
#[b,c,t,h,w]
s = torch.randn((1,128,23,64,64)).to("cuda")


#prompt_emb
#[b,seq_l]
p = torch.randn((1,512)).to("cuda")

attn = AttentionBlock(128,num_groups=32,device="cuda").to("cuda")
s = attn(s,p)
print(s.size())