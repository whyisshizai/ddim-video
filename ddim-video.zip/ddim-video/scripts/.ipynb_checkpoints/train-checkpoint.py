import argparse
import datetime
import torch
import os
import numpy as np
from torch.utils.data import Dataset, DataLoader,random_split
from torchvision import datasets,transforms
import moviepy as mpy
import gc
import torch.nn.parallel
import torch.nn.functional as F
import torch.backends.cudnn as cudnn
import torch.distributed as dist
import torch.utils.data 
import torch.utils.data.distributed
import torch.optim as optim
from torch.autograd import Variable

import sys
from PIL import Image
import vddpm.script_util as script_utils



class VideoDataset(Dataset):
    def __init__(self, file, transform=None):
        # 存储图片文件和标签
        self.file = file
        self.video_files = []
        self.prompt = []
        self.length = []
        # login("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")
        i = 0
        #控制一下dataset的长度
        for filename in os.listdir(file)[:]:
            print(filename)
            if filename.endswith("mp4"):

                i+=1
                #注意RGBA格式
                name = filename.split(".")[0]
                video = mpy.VideoFileClip(f"{file}/{filename}")
                frames = []
                prt = int(name)
                self.prompt.append(prt)
                for frame in video.iter_frames():
                    f =transform(np.array(frame))
                    # [c,h,w]
                    #[3,128,128]
                    f = f.unsqueeze(0).permute(1,0,2,3)
                    # [1,c,h,w]
                    frames.append(f)
                #真实的长度
                self.length.append(len(frames))
                s = len(frames) % 8
                while 8 - s != 0:
                    frames.append(f)
                    s+=1
                #[t,c,h,w]
                self.video_files.append(torch.cat(frames,dim=1))
                #[c,t,h,w]
        print(f"数据库下一共有{i}个文件")
        # self.image_files = torch.from_numpy(np.array(self.image_files))
        self.transform = transform
    def __len__(self):
        return len(self.video_files)
    def __getitem__(self, idx):
        return self.video_files[idx], torch.tensor(0), self.prompt[idx],self.length[idx]



def create_argparser():
    device = torch.device("cuda")
    run_name = datetime.datetime.now().strftime("video-%Y-%m-%d-%H-%M")
    defaults = dict(
        file = r'./datasets/video/64',
        activation = 'mish',
        use_ddim = True,
        learning_rate=2e-4,
        batch_size=1,
        iterations=80000,
        video_size=(64,64),
        video_length=10,
        epoch = 1,
        log_to_wandb=False,
        log_rate=500,
        checkpoint_rate=5000,
        attention_resolutions = (1,0,1,0),
        log_dir=r"None",
        project_name='28_anime_video',
        run_name=run_name,
        model_checkpoint=None,
        optim_checkpoint=None,
        #设定好的
        schedule_low=1e-4,
        schedule_high=0.02,
        device=device,
    )
    defaults.update(script_utils.diffusion_defaults())
    parser = argparse.ArgumentParser()
    script_utils.add_dict_to_argparser(parser, defaults)
    return parser


if __name__ == "__main__":
    args = create_argparser().parse_args()
    device = args.device
    try:
        diffusion = script_utils.get_diffusion_from_args(args).to(device)
        optimizer = torch.optim.Adam(diffusion.parameters(), lr=args.learning_rate)
        
        if args.device:
            diffusion.cuda()
            diffusion = torch.nn.parallel.DistributedDataParallel(diffusion)
        print("video_size",diffusion.video_size)
        print("video length",diffusion.video_length)
        # d = torch.load(
        #     r'D:\pycharm\open-cv\DDPM-main\results\ddpm_test\ddpm_64_anime_face-ddpm-2024-12-21-13-36-iteration-10000-model.pth')
        # o = torch.load(
        #     r"D:\pycharm\open-cv\DDPM-main\results\ddpm_test\ddpm_64_anime_face-ddpm-2024-12-21-13-36-iteration-10000-optim.pth")
        # diffusion.load_state_dict(d)
        # optimizer.load_state_dict(o)

        if args.model_checkpoint is not None:
            diffusion.load_state_dict(torch.load(args.model_checkpoint))
        if args.optim_checkpoint is not None:
            optimizer.load_state_dict(torch.load(args.optim_checkpoint))

        batch_size = args.batch_size
        dataset = VideoDataset(args.file, transform=script_utils.get_transform())
        
        dataset = torch.utils.data.distributed.DistributedSampler(dataset)

        # train_size = int(0.8 * len(dataset))  # 80% 用于训练
        # test_size = len(dataset) - train_size  # 剩余 20% 用于测试
        #
        # train_dataset, test_dataset = random_split(dataset, [train_size, test_size])
        #数据集建造完毕

        
        kwargs = {'num_workers': 1, 'pin_memory': True} if args.cuda else {}
        train_loader = script_utils.cycle(DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=True,
            drop_last=True,
            **kwargs
        ))
        #test_loader = DataLoader(test_dataset, batch_size=batch_size, drop_last=True, num_workers=0)
        print("数据读入完毕")

        gc.collect()

        acc_train_loss = 0
        if args.use_ddim: print("use ddim model")
        else: print("use ddpm model")
        for iteration in range(1, args.iterations + 1):
            diffusion.train()
            x, y ,prompt,l = next(train_loader)

            x = x.to(device)
            y = y.to(device)
            prompt = prompt.to(device)
            #还是不使用长度了把，统统扩到8的倍数  l

            if args.use_labels:
                loss = diffusion(x, y,prompt)
            else:
                loss = diffusion(x,prompt)   

            acc_train_loss += loss.item()

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            diffusion.update_ema()

            if iteration % args.log_rate == 0:
                print(iteration,'test:', loss.item(), "acc:", acc_train_loss)
                acc_train_loss = 0

            if iteration % args.checkpoint_rate == 0:
                print("model and optim is saving")
                model_filename = f"{args.log_dir}/{args.project_name}-{args.run_name}-iteration-{iteration}-model.pth"
                optim_filename = f"{args.log_dir}/{args.project_name}-{args.run_name}-iteration-{iteration}-optim.pth"
                torch.save(diffusion.state_dict(), model_filename)
                torch.save(optimizer.state_dict(), optim_filename)

    except KeyboardInterrupt:
        print("Keyboard interrupt,程序提前结束")
